import random
from sqlalchemy import func, or_, and_
from validations import Validations
from geopy.distance import geodesic
from app import app, db, mail
from flask import request, jsonify, url_for, current_app, send_file, send_from_directory
from datetime import datetime, timedelta
from model import User, PasswordResetToken, Vendor, Event, Booking , Review
import secrets
from sqlalchemy.exc import IntegrityError
import io
import uuid
import json
import base64
from flask_mail import Message
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity, decode_token
from model import bcrypt   
from werkzeug.utils import secure_filename
import os

import sys
sys.dont_write_bytecode = True

###############################     Route For SignUp     ######################################


@app.route('/signup', methods=['POST'])  # Updated route
def signup():
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        role = data.get('role')  # Get the user's role from the request

        # Validate email and password using your Validations class
        email_validation_result = Validations.is_valid_email(email)
        password_validation_result = Validations.is_valid_password(password)

        if email_validation_result is None:
            return jsonify({"message": "Invalid Email Address","status":False}), 400

        if password_validation_result is not None:
            return password_validation_result, 400 # json response result according to the error

        if not email or not password or not role:
            return jsonify({'message': 'Email, password, and role are required',"status":False}), 400

        if User.query.filter_by(email=email).first():
            return jsonify({'message': 'Email already exists',"status":False}), 400

        if role not in ['user', 'vendor']:
            return jsonify({"message": "Invalid Role","status":False}), 400

        user = User(email=email, password=password, role=role)  # Pass the role during user creation

        if role == "vendor":
                vendor = user.vendor
                # If vendor profile doesn't exist then create a new one
                if not vendor:
                    vendor_data = {
                        'full_name': "",
                        'phone_number': "",
                        'location': "",
                        'biography': ""
                    }
                    vendor = Vendor(**vendor_data)
                    user.vendor = vendor
                    #db.session.commit()
        db.session.add(user)
        db.session.commit()
        return jsonify({"status":True, "message": "Registered Successfully !!"})
    except Exception as e:
        print(e)
        return jsonify({"status":False,"message":"errro"})



###############################     Route For SignIn      ######################################


@app.route('/signin', methods=['POST'])
def signin():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        return jsonify({"status":False,'message': 'Invalid credentials'}), 401

    if not user.role:  # This line is not necessary, as 'role' should always be present due to your database model
        return jsonify({"status":False,"message": "Please specify if you are signing in as a user or a vendor"}), 400

    # Generate the access token
    access_token = create_access_token(identity=email)

    # Update the user's access_token column with the new access token
    user.access_token = access_token
    db.session.commit()

    return jsonify({
        "status":True,
        "access_token": access_token,
        "message": "Successfully Logged In !!",
        "role":user.role,
        "id":user.id,
        "profile_image":user.profile_image
    })



###############################     Function For Getting The Current User      ######################################


def get_current_user():
    # Get the identity (user's email) from the JWT token
    current_user_email = get_jwt_identity()
    # Use the email to retrieve the user from the database
    user = User.query.filter_by(email=current_user_email).first()
    return user



###############################     Route For Protected Route      ######################################



@app.route('/protected_route', methods=['GET'])
@jwt_required()
def protected_route():
    user = get_current_user()
    if user:
        return jsonify({ "message": "This route is protected and accessible to authenticated users"})
    else:
        return jsonify({"message": "Authentication failed"}), 401





###############################     Route For Vendor Profile Complete       ######################################

@app.route("/profile", methods=["GET"])
@jwt_required()
def profile():
    try:
        user = get_current_user()
        return jsonify({"status": True, "user": user.as_vendor()})
    except Exception as e:
        print(e)  # Log the error for debugging
        return jsonify({"status": False, "error": str(e)})

@app.route('/complete_vendor_profile', methods=["POST"])
@jwt_required()
def complete_vendor_profile():
    data = request.get_json()
    user = get_current_user()

    if not user:
        return jsonify({ "status":False,"message": "User not found"}), 401

    if user.role != "vendor":
        return jsonify({"status":False,"message": "User Auth Error, not a vendor"}), 401

    full_name = data.get("full_name")
    phone_number = data.get("phone_number")
    location = data.get("location")
    biography = data.get("biography")

    if not all([full_name, phone_number, location, biography]):
        return jsonify({"status":False,"message": "All fields are required for the vendor profile"}), 400

    vendor = user.vendor

    # If vendor profile doesn't exist then create a new one
    if not vendor:
        vendor_data = {
            'full_name': full_name,
            'phone_number': phone_number,
            'location': location,
            'biography': biography
        }
        vendor = Vendor(**vendor_data)
        user.vendor = vendor
        db.session.commit()
        return jsonify({"status":True,"message": "Vendor profile created successfully"})
    
    # else update the existing
    else:
        vendor.full_name = full_name
        vendor.phone_number = phone_number
        vendor.location = location
        vendor.biography = biography
        db.session.commit()
        return jsonify({"status":True,"message": "Vendor profile completed successfully"})
    



VENDOR_IMAGES_FOLDER = 'images'
app.config["VENDOR_IMAGES_FOLDER"] = VENDOR_IMAGES_FOLDER




###############################     Route For Event Management      ######################################

###############################     Create Event       ######################################

# First vendor will be registered or complete his profile then can create event

@app.route("/create_event", methods=["POST"])
@jwt_required()
def create_event():
    data = request.get_json()
    user = get_current_user()

    if not user:
        return jsonify({"status":False, "message": "User not found"}), 401

    if user.role != "vendor":
        return jsonify({"status":False,"message": "User Auth Error, not a vendor"}), 401

    # Ensure the user is associated with a vendor profile
    if not user.vendor:
        return jsonify({"status":False,"message": "User is not associated with a vendor profile"}), 400

    vendor = user.vendor

    # Fields for the event
    thumbnail = data.get("thumbnail")
    other_images = data.get("other_images")
    video_showcase = data.get("video_showcase")
    location_name = data.get("location_name")
    address = data.get("address")
    rate = data.get("rate")
    fixed_price = data.get("fixed_price")

    # Additional fields
    details = data.get("details")
    print("Request Data:", request.get_json())
    services = data.get("services")
    print("Services:", services)

    facilities = data.get("facilities")
    description = data.get("description")
    event_type = data.get("event_type")
    latitude=data.get("latitude")
    longitude = data.get("longitude")

    # Create an event for the vendor
    print(services)
    print(rate,"this was rate")
    event = Event(
        thumbnail=thumbnail,
        other_images=other_images,
        video_showcase=video_showcase,
        location_name=location_name,
        address=address,
        rate=rate,
        fixed_price=fixed_price,
        details=details,
        services=services,
        facilities=facilities,
        description=description,
        event_type=event_type,
        latitude=latitude,
        longitude=longitude,
        vendor=vendor  # Associate the event with the vendor
    )

    # Handle thumbnail image if provided
    if thumbnail:
        thumbnail_filename = f"{uuid.uuid4()}.png"
        thumbnail_path = os.path.join(app.config['VENDOR_IMAGES_FOLDER'], thumbnail_filename)
        save_image_from_base64(thumbnail, thumbnail_path)
        event.thumbnail = thumbnail_filename

    # Handle other images if provided
    if other_images:
        event.other_images = save_multiple_images_from_base64(other_images)

    if facilities:
        event.facilities = save_multiple_images_from_base64(facilities)

    db.session.add(event)  # Add the event to the session
    db.session.commit()  # Commit the transaction

    return jsonify({"status":True,"message": "Event created successfully"})


###############################     Update Event     ######################################

@app.route("/get_my_events", methods=["GET"])
@jwt_required()
def getmyevents():
    try:
        user = get_current_user()
        vendor = user.vendor
        events = Event.query.filter_by(vendor=vendor).all()
        print(events,"ll")
        events_data = []

        for event in events:
            event_dict = event.as_dict()
            event_dict['total_bookings'] = event.get_total_bookings()
            event_dict['total_bookings_value'] = event.earnings_per_month()  # Total earnings for the current month
            events_data.append(event_dict)

        return jsonify({"status": True, "events": events_data})
    except Exception as e:
        print(e)
        return jsonify({"status": False, "events": []})


@app.route("/update_event/<int:event_id>", methods = ["PUT"])
@jwt_required()
def update_event(event_id):
    data = request.get_json()
    user = get_current_user()

    if not user:
        return jsonify({
            "status":False,
            "message":"User Not Found !!"
        })

    if user.role != "vendor":
        return jsonify({
            "status":False,
            "message":"User Authentication Error !!!"
        })

    # Ensuring that user is associated with a vendor profile
    if not user.vendor:
        return jsonify({
            "status":False,
            "message":"User is not associated with a vendor profile make sure to complete the vendor profile first !!! "
        })

    # Basically used this here so that we should know that the user is associated with a vendor profile or not
    # Here we are actually retrieving the vendor profile associated with a user
    vendor = user.vendor

    # Giving the database two pieces of information to find the right event
    # Here vendor is that vendor associated with a user profile

    event = Event.query.filter_by(id = event_id, vendor = vendor).first()
    if not event:   
        return jsonify({
            "status":False,
            "message":"Event Doesn't Exist !!"
        })

    # Updating the fields
    # How it works ? It will get the thumbnail value from field at the time of update but if we don't get the value then it will make it remain for the old value
    event.thumbnail = data.get("thumbnail", event.thumbnail)
    event.other_images = data.get("other_images", event.other_images)
    event.video_showcase = data.get("video_showcase", event.video_showcase)
    event.location_name = data.get("location_name", event.location_name)
    event.address = data.get("address", event.address)
    event.rate = data.get("rate", event.rate)
    event.fixed_price = data.get("fixed_price", event.fixed_price)
    event.details = data.get("details", event.details)
    event.services = data.get("services", event.services)
    event.facilities = data.get("facilities", event.facilities)
    event.description = data.get("description", event.description)
    event.event_type = data.get("event_type", event.event_type)
    event.longitude = data.get("longitude", event.event_type)
    event.latitude = data.get("latitude", event.event_type)

    # Getting the byte codes for the images to be updated
    if data.get("thumbnail"):
        thumbnail_filename = f"{uuid.uuid4()}.png"
        thumbnail_path = os.path.join(app.config["VENDOR_IMAGES_FOLDER"], thumbnail_filename)        
        
        # base 64 data and path to access image from the directory
        # will return filename
        
        save_image_from_base64(data["thumbnail"],thumbnail_path )
        
        # will store the image name i.e, image.png to thumnail column

        event.thumbnail = thumbnail_filename


    if data.get("other_images"):
        event.other_images = save_multiple_images_from_base64(data["other_images"])


    if data.get("facilities"):
        event.facilities = save_multiple_images_from_base64(data["facilities"])


    db.session.commit()

    return jsonify({
        "status":True,
        "message":"Event Updated Successfully !!!"
    })


###############################     Delete Event     ######################################



@app.route("/delete_event/<int:event_id>", methods = ["DELETE"])
@jwt_required()
def delete_event(event_id):
    user = get_current_user()
    
    if not user:
        return jsonify({
            "status":False,
            "message":"User Not Found !!"
        })

    if user.role != "vendor":
        return jsonify({
            "status":False,
            "message":"User Auth Error, Not a vendor !!"
        })

    try:
        # Basically used this here so that we should know that the user is associated with a vendor profile or not
        # Here we are actually retrieving the vendor profile associated with a user
        vendor = user.vendor
        event = Event.query.filter_by(id = event_id , vendor=vendor).first()
        if not event:
          return jsonify({
             "status":False,
             "message":"User Not Found !!"
          })

        db.session.delete(event)
        db.session.commit()
        return jsonify({
           "status":True,
           "message":"Event Deleted Successfully !!!"
        })
    except Exception as e:
        print(e)
        return jsonify({
           "status":False,
           "message":"booking"
        })


 



###############################     Get Event     ######################################

@app.route("/booking_details/<int:booking_id>", methods=["GET"])
@jwt_required()
def booking_details(booking_id):
    try:
        booking = Booking.query.get(booking_id)
        if not booking:
            return jsonify({"status": False, "error": "Booking not found"})

        booking_data = booking.get_booking_with_event_details()
        return jsonify({"status": True, "booking_details": booking_data})
    except Exception as e:
        print(e)
        return jsonify({"status": False, "error": str(e)})


@app.route("/get_event/<int:event_id>", methods = ["GET"])
def get_event(event_id):
    
    event = Event.query.get(event_id) 
    
    if event:
        event_details = {
            "id": event.id,
            "thumbnail": event.thumbnail,
            "other_images": event.other_images,
            "video_showcase": event.video_showcase,
            "location_name": event.location_name,
            "address": event.address,
            "rate": event.rate,
            "fixed_price": event.fixed_price,
            "details": event.details,
            "services": event.services,
            "facilities": event.facilities,
            "description": event.description,
            "event_type": event.event_type,
            "vendor_id": event.vendor_id,  # You can include vendor details if needed
            "custom event name":event.custom_event_name,
            "longitude":event.longitude,
            "latitude":event.latitude
        }
         # Fetch vendor details
        if event.vendor:
            vendor = event.vendor
            vendor_details = {
                "id": vendor.id,
                "full_name": vendor.full_name,
                "phone_number": vendor.phone_number,
                "location": vendor.location,
                "biography": vendor.biography,
                "email":vendor.user[0].email,
                  "profile_image": vendor.user[0].profile_image
                # Include other vendor fields as necessary
            }

     

            event_details['vendor_details'] = vendor_details
        return jsonify({"status":True,"Event Details":event_details})

    else:
        return jsonify({
            "status":False,
            "message":"Event not Found !!"
        })

# decoding image

def save_image_from_base64(base64_data, filename):
    with open(filename, "wb") as image_file:
        image_file.write(base64.b64decode(base64_data))
    return filename

def save_multiple_images_from_base64(base64_images):

    # other_images is an array of base64-encoded images, allowing users to upload multiple images.

    image_paths = []
    for image_base64 in base64_images:
        image_filename = f"{uuid.uuid4()}.png"
        image_path = os.path.join(app.config['VENDOR_IMAGES_FOLDER'], image_filename)
        save_image_from_base64(image_base64, image_path)
        image_paths.append(image_filename)
    return image_paths


def refresh_token_is_valid(refresh_token, current_user):
    try:
        decoded_token = decode_token(refresh_token)
        return decoded_token.get("identity") == current_user
    except Exception as e:
        return False
    
@app.route('/refresh_token', methods=['POST'])
@jwt_required()
def refresh_token():
    refresh_token = request.form.get('refresh_token')
    current_user = get_jwt_identity()
    
    if refresh_token_is_valid(refresh_token, current_user):
        new_access_token = create_access_token(identity=current_user)
        return jsonify(access_token=new_access_token)
    else:
        return jsonify({"status":False,'message': 'Invalid refresh token'}), 401



###############################     Search Events API        ######################################

@app.route("/top_venues/<int:vendor_id>", methods=["GET"])
def top_venues(vendor_id):
    try:
        # Get the total number of bookings for the vendor
        total_bookings = (db.session.query(func.count(Booking.id))
                          .join(Event)
                          .filter(Event.vendor_id == vendor_id)
                          .scalar())

        # Get booking count per venue (using location_name as the venue identifier)
        # venue_bookings = (db.session.query(Event.location_name, func.count(Booking.id).label('booking_count'))
        #                   .join(Event)
        #                   .filter(Event.vendor_id == vendor_id)
        #                   .group_by(Event.location_name)
        #                   .order_by(func.count(Booking.id).desc())
        #                   .all())
        venue_bookings = (db.session.query(Event.location_name, Event.thumbnail, func.count(Booking.id).label('booking_count'))
                          .join(Event)
                          .filter(Event.vendor_id == vendor_id)
                          .group_by(Event.location_name, Event.thumbnail)
                          .order_by(func.count(Booking.id).desc())
                          .all())

        # Calculate the percentage for each venue
        venues_list = []
        # for venue, count in venue_bookings:
        #     percentage = (count / total_bookings) * 100 if total_bookings > 0 else 0
        #     venues_list.append({"venue": venue, "bookings": count, "percentage": round(percentage, 2)})
        for location_name, thumbnail, count in venue_bookings:
            percentage = (count / total_bookings) * 100 if total_bookings > 0 else 0
            venues_list.append({
                "venue": location_name,
                "thumbnail": thumbnail,
                "bookings": count,
                "percentage": round(percentage, 2)
            })


        return jsonify({"status": True, "top_venues": venues_list})
    except Exception as e:
        print(e)
        return jsonify({"status": False, "error": str(e)})


@app.route("/bookings_today/<int:vendor_id>", methods=["GET"])
@jwt_required()
def bookings_today(vendor_id):
    try:
        today = datetime.now().date()
        bookings = Booking.query.join(Event, Booking.event_id == Event.id)\
                                .filter(Event.vendor_id == vendor_id)\
                                .filter(Booking.start_date <= today, Booking.end_date >= today)\
                                .all()

        bookings_data = [booking.booking_today() for booking in bookings]
        return jsonify({"status": True, "bookings": bookings_data})
    except Exception as e:
        print(e)
        return jsonify({"status": False, "error": str(e)})

################### Search Event ###############################

@app.route("/search_event", methods=["POST"])
@jwt_required()
def search_event():
    data = request.get_json()
    event_type = data.get("event_type")
    location_name = data.get("location_name")
    latitude = data.get("latitude")
    longitude = data.get("longitude")

    # Pagination setup
    events_per_page = 10
    page = int(request.args.get("page", 1))
    offset = (page - 1) * events_per_page

    if event_type.lower() != "all":
        # Query based on event_type and location_name
        events = Event.query.filter_by(event_type=event_type, location_name=location_name).offset(offset).limit(events_per_page).all()

        if not events:
            return jsonify({
                "status": False,
                "message": "Events Not Found !!"
            })
    else:
        # Get all events if event_type is "all"
        all_events = Event.query.all()

        # Filter events by location_name if provided, otherwise, consider all events
        if location_name:
            events = [event for event in all_events if event.location_name == location_name]
        else:
            events = all_events

        # Calculate distances for events with latitude and longitude
        user_location = (latitude, longitude)
        results_with_distance = [
            (event, geodesic((event.latitude, event.longitude), user_location).kilometers)
            for event in events 
            if event.latitude is not None and event.longitude is not None
        ]

        # Sort events based on distance in ascending order
        sorted_results = sorted(results_with_distance, key=lambda x: x[1])

        # Paginate the sorted results
        total_events_found = len(sorted_results)
        paginated_results = sorted_results[offset: offset + events_per_page]

        event_list = []
        for event, distance in paginated_results:
            # Search event than since event is connected with vendor so we access vendor details

            vendor_details = {
                "id": event.vendor.id,
                "full_name": event.vendor.full_name,
                "phone_number": event.vendor.phone_number,
                "location": event.vendor.location,
                "biography": event.vendor.biography
            }

            event_info = {
                "id": event.id,
                "thumbnail": event.thumbnail,
                "event_type": event.event_type,
                "custom_event_name": event.custom_event_name,
                "rate": event.rate,
                "fixed_price": event.fixed_price,
                "distance_km": distance,
                "vendor_details": vendor_details
            }
            event_list.append(event_info)

        return jsonify({
            "status": True,
            "Total_Events": total_events_found,
            "Events": event_list
        }), 200

    # If event_type is not "all", proceed with filtered events
    total_events_found = len(events)

    event_list = []
    for event in events:
        vendor_details = {
            "id": event.vendor.id,
            "full_name": event.vendor.full_name,
            "phone_number": event.vendor.phone_number,
            "location": event.vendor.location,
            "biography": event.vendor.biography
        }

        event_info = {
            "id": event.id,
            "thumbnail": event.thumbnail,
            "event_type": event.event_type,
            "custom_event_name": event.custom_event_name,
            "rate": event.rate,
            "fixed_price": event.fixed_price,
            "vendor_details": vendor_details
        }
        event_list.append(event_info)

    return jsonify({
        "status": True,
        "Total_Events": total_events_found,
        "Events": event_list
    }), 200





################### Custom Event Search ###########################

@app.route("/custom_event_search", methods=["POST"])
@jwt_required()
def custom_event_search():
    data = request.get_json()
    event_type = data.get("event_type")
    location_name = data.get("location_name")
    min_price = data.get("min_price")
    max_price = data.get("max_price")
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    start_time = data.get("start_time")
    end_time = data.get("end_time")
    all_day = data.get("all_day")
    latitude = data.get("event_latitude")
    longitude = data.get("event_longitude")
    query = db.session.query(Event)

    # Apply filters based on search criteria
    if event_type:
        query = query.filter(func.lower(Event.event_type) == event_type.lower())

    if location_name:
        query = query.filter(func.lower(Event.location_name) == location_name.lower())

    if min_price is not None and max_price is not None:
        # Both min_price and max_price are provided, filter based on the range
        query = query.filter(Event.rate.between(min_price, max_price))

    elif min_price is not None or max_price is not None:
        # Either min_price or max_price is provided, filter based on the provided value
        if min_price is not None:
            query = query.filter(Event.rate >= min_price)
        elif max_price is not None:
            query = query.filter(Event.rate <= max_price)

    if not all_day and start_date and end_date and start_time and end_time:
    # Subquery to select overlapping event IDs
        subquery = db.session.query(Booking.event_id).filter(
                (Booking.start_date <= end_date)   &
                (Booking.end_date >= start_date)   &
                (Booking.start_time <= end_time)   &
                (Booking.end_time >= start_time)   
        
        ).distinct()

        # Filter events that do not have overlapping bookings
        query = query.filter(~Event.id.in_(subquery))

    results = query.all()

    user_location = (latitude, longitude)
    nearby_events = [
        event for event in results 
        if event.latitude and event.longitude and geodesic ((event.latitude , event.longitude), user_location).kilometers < 3
    ]


    # Serialize Event objects to a list of dictionaries
    serialized_results = []


    print(str(query))

    # First loop is for one event and other is for each vendor specific details 
    for event in nearby_events:
        vendor_details = []
        for vendor_user in event.vendor.user:
            vendor_details.append({
                "vendor_profile_image":vendor_user.profile_image
            })

        serialized_event = {
            "id": event.id,
            "event_type": event.event_type,
            "location_name": event.location_name,
            "rate" : event.rate,
            "thumbnail":event.thumbnail,
            "vendor_details": vendor_details
        }
        serialized_results.append(serialized_event)

    return jsonify({
        "status":True,
        "Search Result Found": f"{len(serialized_results)} vendors found in {location_name}",
        "Search results": serialized_results
    })


###############################   Create Booking      ######################################

@app.route('/create_booking', methods=["POST"])
@jwt_required()
def create_booking():
    try:
        data = request.get_json()
        user = get_current_user()

        if not user:
            return jsonify({
                "status":False,
                "message": "User not authenticated !!"
            })
            
        if user.role != "user":
            return jsonify({
                "status": False,
                "message": "Unauthorized access: Only users can create bookings."
            })

        full_name = data.get('full_name')
        email = data.get('email')
        guest_count = data.get('guest_count')
        additional_notes = data.get('additional_notes', '')
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        all_day = data.get('all_day')
        event_id = data.get('event_id')
        event_type = data.get("event_type")
        if not all([full_name, email, guest_count, start_date, end_date, event_id]):
            return jsonify({
                "status":False,
                "message": "All necessary fields must be set !!"
            })

        # If it's an all-day event, set start_time and end_time accordingly
        if all_day:
            start_time = "00:00:00"
            end_time = "23:59:59"
        else:
            start_time = data.get('start_time', "00:00:00")
            end_time = data.get('end_time', "23:59:59")

        # Calculate total event hours
        event_hours = calculate_event_hours(start_date, end_date, start_time, end_time, all_day)

        overlapping_booking = Booking.query.filter(
            (Booking.event_id == event_id) &
            (Booking.start_date <= start_date) &
            (Booking.end_date >= end_date) &
            (Booking.start_time <= start_time) &
            (Booking.end_time == end_time)
        ).first()

        if overlapping_booking:
            return jsonify({
                "status":False,
                "message": "Event Is already booked !!"
            })

        # Calculate the rate and other values
        event = Event.query.filter_by(id=event_id).first()
        subtotal = event_hours * event.rate
        tax_percentage = 0.15
        total_price = subtotal + (subtotal * tax_percentage)

        # Create and save the booking
        booking = Booking(
            user_id=user.id,
            full_name=full_name,
            email=email,
            guest_count=guest_count,
            additional_notes=additional_notes,
            start_date=start_date,
            end_date=end_date,
            start_time=start_time,
            end_time=end_time,
            all_day=all_day,
            event_id=event_id,
            event_type=event_type
        )

        db.session.add(booking)
        db.session.commit()

        return jsonify({
            "status":True,
            "Summary": {
                "Event Hours": f"{event_hours} Hours",
                "Guests": f"{guest_count}",
                "Vendor Rate": f"{event.rate}$",
                "Subtotal": f"{subtotal}$",
                "Taxes (15%)": "15%",
                "Total Price": f"{total_price} $"
            }
        })

    except Exception as e:
        return jsonify({
            "status":False,
            "message": str(e)
        }), 500

def calculate_event_hours(start_date, end_date, start_time, end_time, all_day):
    # If it's an all-day event, set start_time and end_time accordingly
    if all_day:
        start_time = "00:00:00"
        end_time = "23:59:59"

    # Convert start and end dates/times to datetime objects
    start_datetime = convert_to_datetime(start_date, start_time)
    end_datetime = convert_to_datetime(end_date, end_time)

    # If it's an all-day event, set end_datetime to 23:59:59 of the end_date
    if all_day:
        end_datetime = datetime.combine(end_datetime.date(), datetime.max.time())

    # Calculate total event hours for the specified time duration
    total_hours_for_duration = calculate_hours_for_duration(start_datetime, end_datetime)

    # Calculate the number of days involved
    total_days_involved = calculate_days_involved(start_datetime, end_datetime)

    # Use the minimum of total_hours_for_duration and total_days_involved as event_hours
    event_hours = max(total_hours_for_duration, total_days_involved * 24)

    return event_hours


def convert_to_datetime(date_str, time_str):
    return datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M:%S")


def calculate_hours_for_duration(start_datetime, end_datetime):
    return (end_datetime - start_datetime).total_seconds() / 3600


def calculate_days_involved(start_datetime, end_datetime):
    return (end_datetime.date() - start_datetime.date()).days + 1

###############################################################     Reviews Section      ###############################################################



##############################     Submit Review      ####################################


@app.route("/submit_review", methods=["POST"])
@jwt_required()
def submit_review():
    data = request.get_json()
    user = get_current_user()

    if user.role != "user":
        return jsonify({
            "status": False,
            "message": "Unauthorized access: Only users can create bookings."
        })

    booking_id = data.get("booking_id")
    cleanliness_rating = data.get("cleanliness_rating")
    price_value_rating = data.get("price_value_rating")
    service_value_rating = data.get("service_value_rating")
    location_rating = data.get("location_rating")
    user_review = data.get("user_review")

    reviews_sum = cleanliness_rating + price_value_rating + service_value_rating + location_rating
    average_of_reviews = round((reviews_sum / 4), 1)

    # Check if the booking exists or not
    booking = Booking.query.filter_by(id=booking_id).first()

    if not booking:
        return jsonify({"message": "Booking Does Not Exist!"}), 400

    # Check if the booking belongs to the authenticated user
    if booking.user_id != user.id:
        return jsonify({"message": "Unauthorized: You can only review your own bookings!"}), 403

    booking_end_time = datetime.combine(booking.end_date, booking.end_time)

    if datetime.utcnow() >= booking_end_time:
        user_email = get_jwt_identity()  # Assuming get_jwt_identity() returns email
        user = User.query.filter_by(email=user_email).first()

        if not user:
            return jsonify({"message": "User not found!"}), 400

        existing_review = Review.query.filter_by(booking_id=booking_id, user_id=user.id).first()

        if existing_review:
            return jsonify({"message": "You have already reviewed this event!"}), 400

        new_review = Review(
            booking_id=booking_id,
            event_id=booking.event_id,
            user_id=user.id,  # Use user.id as the user_id
            cleanliness_rating=cleanliness_rating,
            price_value_rating=price_value_rating,
            service_value_rating=service_value_rating,
            location_rating=location_rating,
            user_review=user_review,
            average_rating=average_of_reviews
        )

        try:
            db.session.add(new_review)
            db.session.commit()

            return jsonify({
                "message": "Successfully reviewed !!"
            }), 200

        except IntegrityError as e:
            db.session.rollback()
            return jsonify({
                "message": f"You have already reviewed this event !! {str(e)}"
            }), 400

        except Exception as e:
            db.session.rollback()
            return jsonify({
                "message": f"Failed to rate {str(e)}"
            }), 500

    else:
        return jsonify({"message": "Booking has not been completed yet. Can't rate the event now."}), 400

##############################     Pending Review      ####################################



# @app.route("/pending_reviews", methods=["GET"])
# @jwt_required()
# def pending_reviews():
#     try:
#         # Extract the user's email from the JWT token
#         email = get_jwt_identity()
        
#         # Find the user's ID using the email retrieved from the JWT token
#         user = User.query.filter_by(email=email).first()
        
#         # Get the user ID
#         user_id = user.id

#         # Fetch all bookings made by the user
#         # Fetch all bookings made by the user
#         user_bookings = Booking.query.filter_by(user_id=user_id).all()


#         # Collect unique event IDs associated with the user's bookings
#         user_event_ids = {booking.event_id for booking in user_bookings}

#         # Fetch all reviews made by the user
#         user_reviews = Review.query.filter_by(user_id=user_id).all()


#         # Collect unique event IDs associated with the user's reviewed events
#         user_reviewed_event_ids = {review.event_id for review in user_reviews}

#         # Calculate the difference between booked events and reviewed events
#         pending_event_ids = user_event_ids - user_reviewed_event_ids

#         # Fetch event details for pending reviews
#         pending_reviews_info = []
#         for event_id in pending_event_ids:
#             event = Event.query.get(event_id)
#             if event:
#                 event_rate = event.rate
#                 event_address = event.address
#                 event_thumbnail = event.thumbnail
#                 custom_event_name = event.custom_event_name if event.custom_event_name else "Unknown Custom Event Name"

#                 pending_reviews_info.append({
#                     "event_id": event.id,
#                     "event_rate": event_rate,
#                     "event_address": event_address,
#                     "event_thumbnail": event_thumbnail,
#                     "custom_event_name": custom_event_name
#                 })

#         return jsonify({
#             "Pending Reviews": pending_reviews_info,
#             "Pending Reviews Length": len(pending_reviews_info)
#         })

#     except Exception as e:
#         print(f"Error fetching pending reviews: {str(e)}")
#         return jsonify({"error": "An error occurred while fetching pending reviews."}), 500

# @app.route("/pending_reviews", methods=["GET"])
# @jwt_required()
# def pending_reviews():
#     try:
#         # Extract the user's email from the JWT token
#         email = get_jwt_identity()
        
#         # Find the user's ID using the email retrieved from the JWT token
#         user = User.query.filter_by(email=email).first()
        
#         # Get the user ID
#         user_id = user.id

#         # Fetch all bookings made by the user
#         user_bookings = Booking.query.filter_by(user_id=user_id).all()

#         # Fetch all reviews made by the user
#         user_reviews = Review.query.filter_by(user_id=user_id).all()

#         # Initialize a set to hold reviewed event and booking IDs
#         reviewed_events_bookings = {(review.event_id, review.booking_id) for review in user_reviews}

#         # Collect pending reviews by comparing bookings and reviewed events
#         pending_reviews_info = []
#         for booking in user_bookings:
#             is_reviewed = False
#             for review in user_reviews:
#                 if review.event_id == booking.event_id and review.booking_id == booking.id:
#                     is_reviewed = True
#                     break

#             if not is_reviewed:
#                 event = Event.query.get(booking.event_id)
#                 if event:
#                     event_rate = event.rate
#                     event_type = event.event_type
#                     event_address = event.address
#                     event_thumbnail = event.thumbnail
#                     custom_event_name = event.custom_event_name if event.custom_event_name else "Unknown Custom Event Name"

#                     pending_reviews_info.append({
#                         "event_id": event.id,
#                         "event_rate": event_rate,
#                         "event_address": event_address,
#                         "event_thumbnail": event_thumbnail,
#                         "custom_event_name": custom_event_name
#                     })

#         return jsonify({
#             "Pending Reviews": pending_reviews_info,
#             "Pending Reviews Length": len(pending_reviews_info)
#         })

#     except Exception as e:
#         print(f"Error fetching pending reviews: {str(e)}")
#         return jsonify({"error": "An error occurred while fetching pending reviews."}), 500


@app.route("/pending_reviews", methods=["GET"])
@jwt_required()
def pending_reviews():
    try:
        # Extract the user's email from the JWT token
        email = get_jwt_identity()
        
        # Find the user's ID using the email retrieved from the JWT token
        user = User.query.filter_by(email=email).first()
        
        # Get the user ID
        user_id = user.id

        # Fetch all bookings made by the user
        user_bookings = Booking.query.filter_by(user_id=user_id).all()

        # Fetch all reviews made by the user
        user_reviews = Review.query.filter_by(user_id=user_id).all()

        # Initialize a set to hold reviewed event and booking IDs
        reviewed_events_bookings = {(review.event_id, review.booking_id) for review in user_reviews}

        # Collect pending reviews by comparing bookings and reviewed events
        pending_reviews_info = []
        for booking in user_bookings:
            is_reviewed = False
            for review in user_reviews:
                if review.event_id == booking.event_id and review.booking_id == booking.id:
                    is_reviewed = True
                    break

            if not is_reviewed:
                event = Event.query.get(booking.event_id)
                if event:
                    event_rate = event.rate
                    event_type = event.event_type
                    event_address = event.address
                    event_thumbnail = event.thumbnail
                    custom_event_name = event.custom_event_name if event.custom_event_name else "Unknown Custom Event Name"

                    pending_reviews_info.append({
                        "event_id": event.id,
                        "event_rate": event_rate,
                        "event_type": event_type,
                        "event_address": event_address,
                        "event_thumbnail": event_thumbnail,
                        "custom_event_name": custom_event_name,
                        "booking_date": booking.start_date.isoformat(),
                        "booking_time": booking.start_time.isoformat()
                    })

        return jsonify({
            "Pending Reviews": pending_reviews_info,
            "Pending Reviews Length": len(pending_reviews_info)
        })

    except Exception as e:
        print(f"Error fetching pending reviews: {str(e)}")
        return jsonify({"error": "An error occurred while fetching pending reviews."}), 500


##############################     All Rated Reviews      ####################################


# @app.route('/all_reviews', methods = ["GET"])
# @jwt_required()
# def all_reviews():
#     try:
#         email = get_jwt_identity()

#         user = User.query.filter_by(email=email).first()

#         user_id = user.id

#         reviews = Review.query.filter_by(user_id = user_id).all()
#         print(reviews)

#         if not reviews:
#             return jsonify({
#                 "message":"Reviews Not Found !!"
#             }), 400

#         review_data = []
#         print(review_data)

#         for review in reviews:
#             event = Event.query.filter_by(id = review.event_id).first()
#             print(event)
#             if event:
#                 vendor = event.vendor
#                 vendor_profile_image =  None

#                 if vendor.user and vendor.user.profile_image:
#                     vendor_profile_image = vendor.user.profile_image

#             review_data.append({
#                 "event_name":event.custom_event_name,
#                 "event_rate":event.rate,
#                 "event_address":event.address,
#                 "event_review":review.user_review,
#                 "vendor_profile_image":vendor_profile_image,
#                 "user_review":review.user_review,
#                 "cleanliness_rating":review.cleanliness_rating,
#                 "price_value_rating":review.price_value_rating,
#                 "service_value_rating":review.service_value_rating,
#                 "location_rating":review.location_rating
#             })
        
#         return jsonify({
#             "rated_reviews":review_data,
#             "total_rated_reviews":len(review_data)
#         })

#     except Exception as e:
#         print(f"Error in fetching rated reveiws ! {str(e)}")
#         return jsonify({
#             "error":"An error occured while fetching rated reviews ."
#         }), 500 



# @app.route('/all_reviews', methods=["GET"])
# @jwt_required()
# def all_reviews():
#     try:
#         email = get_jwt_identity()
#         user = User.query.filter_by(email=email).first()

#         user_id = user.id
#         reviews = Review.query.filter_by(user_id=user_id).all()

#         if not reviews:
#             return jsonify({"message": "Reviews Not Found !!"}), 400

#         review_data = []

#         for review in reviews:
#             event = Event.query.filter_by(id=review.event_id).first()

#             if event:
#                 vendor = user.vendor  # Access the vendor associated with the user

#                 if vendor and vendor.profile_image:
#                     vendor_profile_image = vendor.profile_image
#                 else:
#                     vendor_profile_image = None

#                 review_data.append({
#                     "event_name": event.custom_event_name,
#                     "event_rate": event.rate,
#                     "event_address": event.address,
#                     "event_review": review.user_review,
#                     "vendor_profile_image": vendor_profile_image,
#                     # Include other details from the review
#                     "user_review": review.user_review,
#                     "cleanliness_rating": review.cleanliness_rating,
#                     "price_value_rating": review.price_value_rating,
#                     "service_value_rating": review.service_value_rating,
#                     "location_rating": review.location_rating
#                 })

#         return jsonify({
#             "rated_reviews": review_data,
#             "total_rated_reviews": len(review_data)
#         })

#     except Exception as e:
#         print(f"Error in fetching rated reviews: {str(e)}")
#         return jsonify({"error": "An error occurred while fetching rated reviews."}), 500

# @app.route('/all_reviews', methods=["GET"])
# @jwt_required()
# def all_reviews():
#     try:
#         email = get_jwt_identity()
#         user = User.query.filter_by(email=email).first()

#         user_id = user.id
#         reviews = (
#             db.session.query(Review, Event, Vendor)
#             .join(Event, Review.event_id == Event.id)
#             .join(Vendor, Event.vendor_id == Vendor.id)
#             .filter(Review.user_id == user_id)
#             .all()
#         )

#         if not reviews:
#             return jsonify({"message": "Reviews Not Found !!"}), 400

#         review_data = []

#         for review, event, vendor in reviews:
#             vendor_user = User.query.filter_by(vendor_id=vendor.id).first()
#             vendor_profile_image = getattr(vendor_user, 'profile_image', None)

#             review_data.append({
#                 "event_id": event.id,
#                 "event_thumbnail": event.thumbnail,
#                 "event_name": event.custom_event_name,
#                 "event_rate": event.rate,
#                 "event_address": event.address,
#                 "vendor_profile_image": vendor_profile_image,
#                 "user_review": review.user_review,
#                 "cleanliness_rating": review.cleanliness_rating,
#                 "price_value_rating": review.price_value_rating,
#                 "service_value_rating": review.service_value_rating,
#                 "location_rating": review.location_rating
#             })

#         return jsonify({
#             "rated_reviews": review_data,
#             "total_rated_reviews": len(review_data)
#         })

#     except Exception as e:
#         print(f"Error in fetching rated reviews: {str(e)}")
#         return jsonify({"error": "An error occurred while fetching rated reviews."}), 500

@app.route('/all_reviews', methods=["GET"])
@jwt_required()
def all_reviews():
    try:
        email = get_jwt_identity()
        user = User.query.filter_by(email=email).first()

        user_id = user.id
        reviews = (
            db.session.query(Review, Event, Vendor)
            .join(Event, Review.event_id == Event.id)
            .join(Vendor, Event.vendor_id == Vendor.id)
            .filter(Review.user_id == user_id)
            .all()
        )

        if not reviews:
            return jsonify({"message": "Reviews Not Found !!"}), 400

        review_data = []

        for review, event, vendor in reviews:
            vendor_user = User.query.filter_by(vendor_id=vendor.id).first()
            vendor_profile_image = getattr(vendor_user, 'profile_image', None)

            review_data.append({
                "event_id": event.id,
                "event_thumbnail": event.thumbnail,
                "event_name": event.custom_event_name,
                "event_rate": event.rate,
                "event_address": event.address,
                "vendor_profile_image": vendor_profile_image,
                "user_review": review.user_review,
                "cleanliness_rating": review.cleanliness_rating,
                "price_value_rating": review.price_value_rating,
                "service_value_rating": review.service_value_rating,
                "location_rating": review.location_rating
            })

        return jsonify({
            "rated_reviews": review_data,
            "total_rated_reviews": len(review_data)
        })

    except Exception as e:
        print(f"Error in fetching rated reviews: {str(e)}")
        return jsonify({"error": "An error occurred while fetching rated reviews."}), 500




###############################     Upload Profile Image      ######################################


# remaining work : don't ask for email 

@app.route('/upload_profile_image', methods=["POST"])
@jwt_required()
def upload_profile_image():
    UPLOAD_FOLDER = 'images'
    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

    data = request.get_json()
    profile_image = data.get("profile_image")

    try:    
        user_email = get_jwt_identity()

        if not profile_image:
            return jsonify({"status":False,"message": "No profile image provided!!"}), 400

        image_bytes = base64.b64decode(profile_image)

        # If images directory dont exist then make it !!
        if not os.path.exists(UPLOAD_FOLDER):
            os.makedirs(UPLOAD_FOLDER)

        original_extension = data.get("extension", "png")

        # Generate a new unique filename using a UUID
        filename = str(uuid.uuid4())

        # Combine the folder path and the filename with the original extension
        output_file_name = os.path.join(app.config['UPLOAD_FOLDER'], f"{filename}.{original_extension}") # images / uuid name
        filename_path = f"{filename}.{original_extension}" # just uuid name

        with open(output_file_name, "wb") as output_file: # wb is write binary
            output_file.write(image_bytes)

        print(f"Image saved as {output_file_name}")

        # Assuming you have a User model and a database connection
        # Update the user's profile_image field with the new file path
        user = User.query.filter_by(email=user_email).first()
        if user:
            user.profile_image = filename_path
            db.session.commit()

        return jsonify({"status":True,"message": "Image uploaded successfully", "file_path": output_file_name}), 200

    except Exception as e:
        return jsonify({"status":False,"message": str(e)}), 500 
    
###############################     Update Profile Image      ######################################


@app.route('/update_profile_image', methods=["POST"])
@jwt_required()
def update_profile_image():
    UPLOAD_FOLDER = 'images'
    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

    data = request.get_json()
    profile_image = data.get("profile_image")
    
    try:
        user_email = get_jwt_identity()
        user = User.query.filter_by(email=user_email).first()

        if not profile_image:
            return jsonify({"status":False,"message": "No profile image provided!!"}), 400

        if user.profile_image:
            # Delete the old image file if it exists
            old_image_path = os.path.join(app.config['UPLOAD_FOLDER'], user.profile_image)
            if os.path.exists(old_image_path):
                os.remove(old_image_path)

        image_bytes = base64.b64decode(profile_image)

        if not os.path.exists(UPLOAD_FOLDER):
            os.makedirs(UPLOAD_FOLDER)

        original_extension = data.get("extension", "png")

        filename = str(uuid.uuid4())
        output_file_name = os.path.join(app.config['UPLOAD_FOLDER'], f"{filename}.{original_extension}")
        filename_path = f"{filename}.{original_extension}"

        with open(output_file_name, "wb") as output_file:
            output_file.write(image_bytes)

        user.profile_image = filename_path
        db.session.commit()

        return jsonify({"status":True,"message": "Profile image updated successfully", "file_path": filename_path}), 200

    except Exception as e:
        return jsonify({"status":False,"message": str(e)}), 500
    

###############################     Delete Profile Image      ######################################

# No need for delete profile as while updating the image with the new one it will automatically delete the new one

###############################     Get Profile Image      ######################################

# @app.route('/get_profile_image', methods=["GET"])
# @jwt_required()
# def get_profile_image():
#     user_email = get_jwt_identity()
#     user = User.query.filter_by(email=user_email).first()

#     if user and user.profile_image:
#         file_path = os.path.join(app.config['UPLOAD_FOLDER'], user.profile_image)
#         if os.path.exists(file_path):
#             return send_file(file_path, as_attachment=True)
    
#     return jsonify({"message": "Profile image not found"}), 404

@app.route('/get_profile_image', methods=["GET"])
@jwt_required()
def get_profile_image():
    user_email = get_jwt_identity()
    user = User.query.filter_by(email=user_email).first()

    if user and user.profile_image:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], user.profile_image)
        if os.path.exists(file_path):
            return send_file(file_path)
    
    return jsonify({"message": "Profile image not found"}), 404


# getting the image

@app.route('/images/<image_name>')
def serve_image(image_name):
    print("dssdfsfsfsdf")
    return send_from_directory('images', image_name)


###############################     Route For Reset Password      ######################################


@app.route('/reset_password', methods=['POST'])
def reset_password_request():
    data = request.get_json()
    email = data.get('email')

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({'message': 'User Not Found !!'}), 404

    reset_token = secrets.token_urlsafe(32)
    reset_token_obj = PasswordResetToken(user_id=user.id, token=reset_token, expires_in_minutes=60)
    db.session.add(reset_token_obj)
    db.session.commit()

    reset_link = url_for('reset_password', token=reset_token, _external=True)
    msg = Message('Password Reset', sender='noreply@gmail.com', recipients=[user.email])
    msg.body = f"Click on the following link to reset the password: {reset_link}"

    try:
        mail.send(msg)
        return jsonify({"message": "Password Reset Email Sent !!"})
    except Exception as e:
        return jsonify({"message": f"Email sending failed: {str(e)}"}), 500
    


###############################     Route For Reset Password After Getting Token      ######################################

@app.route('/password_reset', methods=['POST'])
def reset_password():
    data = request.get_json()
    new_password = data.get('new_password')
    confirm_password = data.get('confirm_password')
    current_password = data.get('current_password')
    email = data.get('email')
    print(new_password,confirm_password,current_password)
    user = User.query.filter_by(email=email).first()

    if not user or not user.check_password(current_password):
        return jsonify({"status":False,'message': 'Invalid credentials'}), 401
    
    if user.check_password(new_password):
        return jsonify({"status":False,"message":"same_password"})



    password_validation_result = Validations.is_valid_password(new_password)

    if new_password != confirm_password:
        return jsonify({
            "status":False,
            "message": "Password did not match."
        }), 400
    user.password_hash = bcrypt.generate_password_hash(new_password).decode('utf-8')
    db.session.commit()
    return jsonify({"status":True,'message': 'Password reset successfully'}), 200


# @app.route('/reset_password/<token>', methods=['POST'])
# def reset_password(token):
#     data = request.get_json()
#     new_password = data.get('new_password')
#     confirm_password = data.get('confirm_password')

#     password_validation_result = Validations.is_valid_password(new_password)

#     if new_password != confirm_password:
#         return jsonify({
#             "status":False,
#             "message": "Password did not match."
#         }), 400
    

#     reset_token_obj = PasswordResetToken.query.filter_by(token=token).first()
#     if not reset_token_obj:
#         return jsonify({"status":False,'message': 'Invalid reset token'}), 400

#     if reset_token_obj.expired_at < datetime.utcnow():
#         return jsonify({"status":False,'message': 'Reset token has expired'}), 400

#     user = User.query.get(reset_token_obj.user_id)
#     user.password_hash = bcrypt.generate_password_hash(new_password).decode('utf-8')
#     db.session.delete(reset_token_obj)
#     db.session.commit()

#     return jsonify({"status":True,'message': 'Password reset successfully'}), 200


if __name__ == '__main__':
    app.run(debug=True)

